"""The round loop.

``run_game`` simulates a full auction for one group of bots under one variation
and returns a :class:`GameResult`.

Round procedure (problem statement §3):
    1. draw x_i for every active player           (distributions.ValueSampler)
    2. hand each active bot its observation and collect a bid   (player.Player.ask)
    3. legality is handled in Player: bid > capital -> 0; bid clamped to [0, max_bid]
    4. winner(s) = highest bid (bids within TIE_EPSILON of the top all win)
    5. payoffs per variation                       (variations)
    6. capital += payoff; eliminate at capital <= ELIMINATION_CAPITAL
    7. record this round's highest / second-highest bid   (history.BidHistory)

Provisional decisions (flagged in docs/bot_interface.md, to revisit in 1.B):
    - tie for first: every tied bidder wins and gets the FULL winner payoff.
    - "second-highest bidder" (V3) = the bidders at the highest bid strictly below
      the winning bid. If there is no lower bid, nobody pays the V3 penalty.
    - the game stops early only when fewer than 2 players are active.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import variations
from .config import ELIMINATION_CAPITAL, HISTORY_WINDOW, NUM_ROUNDS, TIE_EPSILON
from .distributions import ValueSampler
from .history import BidHistory
from .player import Player


@dataclass
class PlayerSummary:
    player_id: int
    starting_capital: float
    final_capital: float
    net_profit: float
    wins: int
    eliminated_round: int | None
    error_count: int


@dataclass
class GameResult:
    variation: int
    rounds_played: int
    players: list[PlayerSummary]
    # capital_by_round[r][i] = capital of player i at the end of round r
    capital_by_round: list[list[float]] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"Variation {self.variation}  |  {self.rounds_played} rounds played",
            f"  {'bot':>4}  {'start':>10}  {'final':>12}  {'net':>12}  {'wins':>6}  {'elim@':>6}  {'errs':>5}",
        ]
        for p in self.players:
            elim = "-" if p.eliminated_round is None else str(p.eliminated_round)
            lines.append(
                f"  {p.player_id:>4}  {p.starting_capital:>10.2f}  {p.final_capital:>12.2f}  "
                f"{p.net_profit:>+12.2f}  {p.wins:>6}  {elim:>6}  {p.error_count:>5}"
            )
        return "\n".join(lines)


def _winning_and_second(bids: list[float]):
    """Return (top, winner_idxs, second_or_None, second_idxs)."""
    top = max(bids)
    winner_idxs = [i for i, b in enumerate(bids) if b >= top - TIE_EPSILON]
    below = [b for b in bids if b < top - TIE_EPSILON]
    if not below:
        return top, winner_idxs, None, []
    second = max(below)
    second_idxs = [i for i, b in enumerate(bids) if abs(b - second) <= TIE_EPSILON]
    return top, winner_idxs, second, second_idxs


def run_game(
    bot_classes,
    *,
    variation: int,
    starting_capitals,
    block_bounds,
    seed: int,
    max_bid: float,
    num_rounds: int = NUM_ROUNDS,
    sampler=None,
) -> GameResult:
    """Simulate one group of bots for one variation.

    bot_classes       : list of classes, each defining ``Bot(config)`` with ``get_bid(obs)``
    variation          : 1, 2 or 3
    starting_capitals  : a single number (all bots) or a list (one per bot)
    block_bounds       : list of (lo, hi) uniform bounds, one per 500-round block
    seed               : RNG seed -> reproducible run
    max_bid            : legal bid ceiling
    sampler            : optional; injected value source (tests). Defaults to a
                         ``ValueSampler(block_bounds, seed)``.
    """
    if variation not in variations.VARIATIONS:
        raise ValueError(f"variation must be one of {variations.VARIATIONS}")

    n = len(bot_classes)
    if isinstance(starting_capitals, (int, float)):
        caps = [float(starting_capitals)] * n
    else:
        caps = [float(c) for c in starting_capitals]
        if len(caps) != n:
            raise ValueError("starting_capitals length must match bot_classes")

    if sampler is None:
        sampler = ValueSampler(block_bounds, seed)

    players = [
        Player(cls, i, caps[i], variation, max_bid, n, num_rounds)
        for i, cls in enumerate(bot_classes)
    ]
    history = BidHistory(window=HISTORY_WINDOW)
    capital_by_round: list[list[float]] = []

    rounds_played = 0
    for r in range(num_rounds):
        active = [p for p in players if p.active]
        if len(active) < 2:
            break
        rounds_played += 1
        n_active = len(active)

        values = sampler.draw(r, n_active)
        max_value = float(max(values))

        hist_high = history.highest_last_100()
        hist_second = history.second_highest_last_100()
        hist_high_series = history.highest_series()
        hist_second_series = history.second_series()

        bids: list[float] = []
        for i, p in enumerate(active):
            obs = {
                "round": r,
                "x": float(values[i]),
                "capital": p.capital,
                "num_players": n_active,
                "max_bid": float(max_bid),
                "highest_bid_last_100": hist_high,
                "second_highest_bid_last_100": hist_second,
                "highest_bids": hist_high_series,
                "second_highest_bids": hist_second_series,
            }
            bids.append(p.ask(obs))

        top, winner_idxs, second, second_idxs = _winning_and_second(bids)

        payoffs = [0.0] * n_active
        for i in winner_idxs:
            if variation == 1:
                payoffs[i] = variations.payoff_v1(values[i], top)
            elif variation == 2:
                payoffs[i] = variations.payoff_v2(max_value, top)
            else:
                payoffs[i] = variations.payoff_v3_winner(max_value, top)
            active[i].wins += 1

        if variation == 3 and second is not None:
            second_payoff = variations.payoff_v3_second(max_value, top)
            for i in second_idxs:
                payoffs[i] = second_payoff

        for i, p in enumerate(active):
            p.settle(payoffs[i], r)

        history.record(top, second if second is not None else 0.0)
        capital_by_round.append([p.capital for p in players])

    result_players = [
        PlayerSummary(
            player_id=p.id,
            starting_capital=p.starting_capital,
            final_capital=p.capital,
            net_profit=p.capital - p.starting_capital,
            wins=p.wins,
            eliminated_round=p.eliminated_round,
            error_count=p.error_count,
        )
        for p in players
    ]
    return GameResult(
        variation=variation,
        rounds_played=rounds_played,
        players=result_players,
        capital_by_round=capital_by_round,
    )
