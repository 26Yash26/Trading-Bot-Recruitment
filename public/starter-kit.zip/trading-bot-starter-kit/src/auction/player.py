"""Wrapper around a participant's bot instance.

Owns everything the engine should not care about: constructing the bot, calling
``get_bid`` and sanitising what comes back, tracking capital and bankruptcy, and
remembering what happened to this bot last round so the next observation can
report it back.

Legality (problem statement §4.7): a bid above the player's available capital,
below zero, not a number, or not returned in time is filed as 0 for that round.
The legal ceiling is the player's own capital — ``max_bid`` stays as an optional
fixed ceiling so the engine's unit tests can pin payoff arithmetic.
"""

from __future__ import annotations

import math

from .config import ELIMINATION_CAPITAL


class Player:
    """See module docstring."""

    def __init__(
        self,
        bot_cls,
        player_id: int,
        starting_capital: float,
        variation: int,
        max_bid: float,
        num_players: int,
        num_rounds: int,
    ):
        self.id = int(player_id)
        self.starting_capital = float(starting_capital)
        self.capital = float(starting_capital)
        self.active = self.capital > ELIMINATION_CAPITAL
        self.wins = 0
        self.eliminated_round = None  # first round this bot went bankrupt
        self.error_count = 0

        # Reported back to the bot in the next round's observation.
        self.last_bid = 0.0
        self.last_rank = 0
        self.last_payoff = 0.0

        self._max_bid = float(max_bid)
        config = {
            "player_id": self.id,
            "variation": int(variation),
            "num_players": int(num_players),
            "num_rounds": int(num_rounds),
            "starting_capital": self.starting_capital,
            "max_bid": self._max_bid,
        }
        # A crash in the constructor is the participant's bug -- let it surface
        # here (run_local / harness decide what to do with it).
        self._bot = bot_cls(config)

    def legal_ceiling(self) -> float:
        """The largest bid this player may legally make right now."""
        return min(self._max_bid, self.capital)

    def begin_block(self, capital: float) -> None:
        """Start a new block on freshly drawn capital.

        Bankruptcy is scoped to a block, so a bot that went broke comes back
        here. Its own bot object is untouched: internal state is deliberately
        carried across the boundary, because detecting the boundary is part of
        the problem.
        """
        self.capital = float(capital)
        self.active = self.capital > ELIMINATION_CAPITAL
        self.last_bid = 0.0
        self.last_rank = 0
        self.last_payoff = 0.0

    def ask(self, obs) -> float:
        """Call the bot for its bid this round and return a legal bid."""
        try:
            raw = self._bot.get_bid(obs)
        except Exception:  # noqa: BLE001 - participant code, never trust it
            self.error_count += 1
            return 0.0
        return self._sanitise(raw, obs["capital"])

    def _sanitise(self, raw, capital: float) -> float:
        try:
            bid = float(raw)
        except (TypeError, ValueError):
            self.error_count += 1
            return 0.0
        if not math.isfinite(bid) or bid < 0.0:
            self.error_count += 1
            return 0.0
        if bid > self._max_bid:
            bid = self._max_bid          # a fixed ceiling clamps rather than voids
        if bid > capital:
            return 0.0                   # illegal bid -> 0 (problem statement §4.7)
        return bid

    def settle(self, payoff: float, round_idx: int, *, bid: float = 0.0, rank: int = 0) -> None:
        """Apply a round payoff and update bankruptcy status."""
        self.capital += float(payoff)
        self.last_bid = float(bid)
        self.last_rank = int(rank)
        self.last_payoff = float(payoff)
        if self.active and self.capital <= ELIMINATION_CAPITAL:
            self.capital = max(0.0, self.capital)
            self.active = False
            if self.eliminated_round is None:
                self.eliminated_round = int(round_idx)
