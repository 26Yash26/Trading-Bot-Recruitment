"""Starting capital, redrawn at every block boundary (problem statement §3.1).

For each player independently, at the start of block b::

    kappa ~ U[0.5, 2.5]
    y     = kappa * M_b            (M_b is that block's hidden maximum value)
    u     ~ U[-10, 10]
    C     = max(y + u, 0.05 * M_b)

So inside one block some bots start rich and some start poor, nobody is told
anyone else's capital, and the floor only bites when M_b is small — it exists to
stop a zero or negative starting capital.

The bounds are parameters rather than constants because the admin console can
tune them between showdowns.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CapitalDraw:
    """How a block's starting capital is drawn. Defaults follow the PS."""

    kappa_lo: float = 0.5
    kappa_hi: float = 2.5
    jitter_lo: float = -10.0
    jitter_hi: float = 10.0
    floor_fraction: float = 0.05

    def draw(self, rng, block_max: float) -> float:
        """One player's starting capital for a block with maximum ``block_max``."""
        block_max = float(block_max)
        kappa = rng.uniform(self.kappa_lo, self.kappa_hi)
        jitter = rng.uniform(self.jitter_lo, self.jitter_hi)
        return max(kappa * block_max + jitter, self.floor_fraction * block_max)

    def as_dict(self) -> dict:
        return {
            "kappa_lo": self.kappa_lo,
            "kappa_hi": self.kappa_hi,
            "jitter_lo": self.jitter_lo,
            "jitter_hi": self.jitter_hi,
            "floor_fraction": self.floor_fraction,
        }

    @classmethod
    def from_settings(cls, settings: dict | None) -> "CapitalDraw":
        settings = settings or {}
        base = cls()
        return cls(
            kappa_lo=float(settings.get("kappa_lo", base.kappa_lo)),
            kappa_hi=float(settings.get("kappa_hi", base.kappa_hi)),
            jitter_lo=float(settings.get("jitter_lo", base.jitter_lo)),
            jitter_hi=float(settings.get("jitter_hi", base.jitter_hi)),
            floor_fraction=float(settings.get("floor_fraction", base.floor_fraction)),
        )
